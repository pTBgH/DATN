# Flows by Source Namespace

_Captured at /home/ptb/zta-microseg/20260521-221527_
