# Microsegmentation Step 1 — Summary

- Total namespaces có pod: **15**
- Namespaces có CiliumNetworkPolicy: **4** (['gateway', 'job7189-apps', 'monitoring', 'security'])
- Namespaces CHƯA có CNP: **11** (['cert-manager', 'cosign-system', 'data', 'gatekeeper-system', 'ingress-nginx', 'kube-system', 'local-path-storage', 'management', 'spire', 'trivy-system', 'vault'])
- Unique flow đã capture: **0**
- Flow DROPPED: **0**
- Flow FORWARDED: **0**

## Top namespaces có nhiều DROPPED flow (cần điều tra)
| ns | drop count |
|---|---|

## Đề xuất bước tiếp
1. Đọc `11-flows-by-src-ns.md` để hiểu luồng thực tế của từng ns.
2. Đối chiếu với `doc/20-5w1h-policy-matrix.md` — flow nào hợp pháp nhưng chưa có policy?
3. Sinh CNP default-deny + allowlist cho từng ns chưa có policy.
4. Apply theo thứ tự: ns ít flow → ns nhiều flow (để giảm rủi ro).